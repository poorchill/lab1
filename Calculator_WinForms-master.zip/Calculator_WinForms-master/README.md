# Calculator project made by using C# and Windows Forms

![Calculator_15nG9cMxnJ](https://user-images.githubusercontent.com/91478447/220352802-2a89399a-d12b-4c3c-bf13-05d5b4d368a7.png)

# Unit tests

![devenv_nDoi3Kiq8w](https://user-images.githubusercontent.com/91478447/225322196-752097f9-a3ec-41c5-9ad3-31139efaa2ef.png)
